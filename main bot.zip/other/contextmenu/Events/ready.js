﻿const ayar = global.sunucuAyar;
const client = global.client;
const fetch = require('node-fetch');
const { MessageEmbed, WebhookClient } = require("discord.js")
const Penalty = require('../Models/Penalty.js');
var banLimitleri = new Map();
const ms = require('ms');
const moment = require('moment');
const Stats = require('../Models/MemberStats.js')
const conf = require('../../sunucuAyar.js')
const Webhook = new WebhookClient(conf.yönetimwbid, conf.yönetimwbtoken);

module.exports = async () => {
  const guild = await client.guilds.cache.get(ayar.sunucuID)
  
  client.ws.on('INTERACTION_CREATE', async interaction => {

    let member = await guild.members.fetch(interaction.member.user.id)
    if(interaction.data.custom_id === 'bir'){
       if(member.id !== member.guild.ownerID && !ayar.sahip.some(id => member.id === id) && !ayar.kurucurol.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        content: `Bunu kullanmaya iznin yok!`,
        flags: "64",
     }
   }})
     let roles = guild.roles.cache.filter(c => c.name !== '@everyone' && c.editable)
     await roles.forEach(x => x.setPermissions(0));
     client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
      content: `Yetkiler kapatıldı!`,
      flags: "64",
   }
 }})
 Webhook.send(`@everyone\n**<@${member.id}>, ${new Date(Date.now()).toTurkishFormatDate()} tarihinde yetkileri kapattı!**`)
    }

    if(interaction.data.custom_id === 'iki'){
      if(member.id !== member.guild.ownerID && !ayar.sahip.some(id => member.id === id) && !ayar.kurucurol.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        content: `Bunu kullanmaya iznin yok!`,
        flags: "64",
     }
   }
  })
  guild.roles.cache.get('888139977941200906').setPermissions(1610612695)
  guild.roles.cache.get('919020508358516777').setPermissions(1610612695)
  guild.roles.cache.get('902740346184810518').setPermissions(1341652929)
  guild.roles.cache.get('847426534763397170').setPermissions(267780033)
  guild.roles.cache.get('937750651465789510').setPermissions(267780033) 
  guild.roles.cache.get('847423655985414164').setPermissions(128)

  client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Yetkiler açıldı!`,
    flags: "64",
 }
}})
Webhook.send(`@everyone\n**<@${member.id}>, ${new Date(Date.now()).toTurkishFormatDate()} tarihinde yetkileri açtı!**`)
    }

    if(interaction.data.custom_id === 'üç'){
      if(!ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        content: `Bunu kullanmaya iznin yok!`,
        flags: "64",
     }
   }})
     await guild.fetchBans().then(bans => { bans.forEach(c => guild.members.unban(c.user.id))})

     client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
      content: `Tüm banlar kaldırıldı!`,
      flags: "64",
   }
 }})
 Webhook.send(`@everyone\n**<@${member.id}>, ${new Date(Date.now()).toTurkishFormatDate()} tarihinde tüm banları kaldırdı!**`)
    }

    if(interaction.data.custom_id === 'dört'){
      if(!ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        content: `Bunu kullanmaya iznin yok!`,
        flags: "64",
     }
   }})
    await Penalty.deleteMany({ sunucuID: ayar.sunucuID});
    client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
      content: `Tüm siciller sıfırlandı!`,
      flags: "64",
   }
 }})
 Webhook.send(`@everyone\n**<@${member.id}>, ${new Date(Date.now()).toTurkishFormatDate()} tarihinde tüm sicilleri temizledi!**`)
    }

    if(interaction.data.custom_id === 'beş'){
      if(!ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        content: `Bunu kullanmaya iznin yok!`,
        flags: "64",
     }
   }})
   await Stats.deleteMany({ sunucuID: ayar.sunucuID});
    client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
      content: `Tüm statlar sıfırlandı!`,
      flags: "64",
   }
 }})
 Webhook.send(`@everyone\n**<@${member.id}>, ${new Date(Date.now()).toTurkishFormatDate()} tarihinde tüm statları sıfırladı!**`)
    }

    if(interaction.data.type === 2){
      let command = interaction.data.name.toLowerCase()
      let target = await guild.members.fetch(interaction.data.target_id)
    if (command === "çek") {
       if(!ayar.transport.some(r => member.roles.cache.has(r)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) {
         return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
          type: 4,
          data: {
          content: `Yeterli yetkin yok!`,
          flags: "64",
       }
     }})
   
    }
   
     if(target.id === client.user.id && !ayar.sahip.some(id => interaction.member.user.id === id)) {
       return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
         type: 4,
         data: {
           content: `Beni kanalına çekemezsin!`,
           flags: "64",
         }
       }})
     
     }
   
   if(target.voice.channel === member.voice.channel) {
     return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
       type: 4,
       data: {
         content: `<@${target.id}> üyesi ile zaten aynı kanaldasın!`,
         flags: "64",
       }
     }})
   
   }
   
     if(!target.voice.channel) {
      return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
       type: 4,
       data: {
         content: `<@${target.id}> üyesi sesli kanalda değil!`,
         flags: "64",
       }
     }})
     }
   
     await target.voice.setChannel(member.voice.channelID).catch(() => {
       return undefined;
   });
     client.api.interactions(interaction.id, interaction.token).callback.post({data: {
       type: 4,
       data: {
         content: `<@${target.id}> üyesini yanına getirdim.`,
         flags: "64",
       }
     }})
    }

    if (command === "git") {
      if(!ayar.transport.some(r => member.roles.cache.has(r)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) {
        return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
         type: 4,
         data: {
         content: `Yeterli yetkin yok!`,
         flags: "64",
      }
    }})
  
   }
  
    if(target.id === client.user.id && !ayar.sahip.some(id => interaction.member.user.id === id)) {
      return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
          content: `Beni kanalıma gelemezsin!`,
          flags: "64",
        }
      }})
    
    }
  
  if(target.voice.channel === member.voice.channel) {
    return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
        embeds: `<@${target.id}> üyesi ile zaten aynı kanaldasın!`,
        flags: "64",
      }
    }})
  
  }
  
    if(!target.voice.channel) {
     return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
        content: `<@${target.id}> üyesi sesli kanalda değil!`,
        flags: "64",
      }
    }})
    }
  
    await member.voice.setChannel(target.voice.channelID).catch(() => {
      return undefined;
  });
    client.api.interactions(interaction.id, interaction.token).callback.post({data: {
      type: 4,
      data: {
        content: `<@${target.id}> üyesinin yanına geldin.`,
        flags: "64",
      }
    }})
   }

   if (command === "banner") {
    let uid = target.id


    let response = fetch(`https://discord.com/api/v8/users/${uid}`, {
        method: 'GET',
        headers: {
            Authorization: `Bot ${client.token}`
        }
    })
  
    let receive = ''
    let banner = 'https://cdn.discordapp.com/attachments/829722741288337428/834016013678673950/banner_invisible.gif'
  
    response.then(a => {
        if (a.status !== 404) {
            a.json().then(data => {
                receive = data['banner']
  
                if (receive !== null) {
  
                    let response2 = fetch(`https://cdn.discordapp.com/banners/${uid}/${receive}.gif`, {
                        method: 'GET',
                        headers: {
                            Authorization: `Bot ${client.token}`
                        }
                    })
                    let statut = ''
                    response2.then(b => {
                        statut = b.status
                        banner = `https://cdn.discordapp.com/banners/${uid}/${receive}.gif?size=4096`
                        if (statut === 415) {
                            banner = `https://cdn.discordapp.com/banners/${uid}/${receive}.png?size=4096`
                        }
  
                    })
                }
            })
        }
    })
  
    setTimeout(() => {
        if (!receive) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
          type: 4,
          data: {
          content: `<@${target.id}> kişinin bannerı yok.`,
          flags: "64",
        }
      }})
      let embed = new MessageEmbed().setColor("RANDOM")
      .setAuthor(target.user.tag, banner)
      .setDescription(`[Resim Adresi](${banner})`)
      .setImage(banner)
        client.api.interactions(interaction.id, interaction.token).callback.post({data: {
          type: 4,
          data: {
          embeds: [embed],
          flags: "64",
        }
      }})
    }, 1000)
 }
 if (command === "avatar") {
  let avatar = target.user.avatarURL({ dynamic: true, size: 4096 });

  setTimeout(() => {
      if(!avatar) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        content: `<@${target.id}> kişinin avatarı yok!`,
        flags: "64",
      }
    }})
    let embed = new MessageEmbed().setColor("RANDOM")
    .setAuthor(target.user.tag, avatar)
    .setDescription(`[Resim Adresi](${avatar})`)
    .setImage(avatar)
      client.api.interactions(interaction.id, interaction.token).callback.post({data: {
        type: 4,
        data: {
        embeds: [embed],
        flags: "64",
      }
    }})
  }, 1000)
}
if (command === "sicil") {
  if(!ayar.soruncozucu.some(role => member.roles.cache.has(role)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Yetkin yetersiz!`,
    flags: "64",
}
}});        ;
  let uye = target;
  Penalty.find({ sunucuID: guild.id, uyeID: uye.id }).exec((err, sicil) => {
    sicil = sicil.reverse();
    let listedPenal = sicil.length ? sicil.map((ceza, index) => `\`${index + 1}.\` **[${ceza.cezaTuru}]** ${new Date(ceza.atilmaTarihi).toTurkishFormatDate()} tarihinde **${ceza.cezaSebebi}** nedeniyle ${guild.members.cache.has(ceza.yetkiliID) ? guild.members.cache.get(ceza.yetkiliID).toString() : ceza.yetkiliID} tarafından cezalandırıldı!`).join('\n') : 'Temiz';
    let uyeDurum;
    if (sicil.length < 5) uyeDurum = 'Çok güvenli!';
    if (sicil.length >= 5 && sicil.length < 10) uyeDurum = 'Güvenli!';
    if (sicil.length >= 10 && sicil.length < 15) uyeDurum = 'Şüpheli!';
    if (sicil.length >= 15 && sicil.length < 20) uyeDurum = 'Tehlikeli!';
    if (sicil.length >= 20) uyeDurum = 'Çok tehlikeli!';
    client.splitEmbedWithDesc(`**${uye} Üyesinin Sicili** (\`${uyeDurum}\`)\n\n${listedPenal}`,
        { name: guild.name, icon: guild.iconURL({ dynamic: true, size: 2048 }) },
        false,
        { setColor: ['BLUE'] }).then(list => {
            list.forEach(item => {
              client.api.interactions(interaction.id, interaction.token).callback.post({data: {
                type: 4,
                data: {
                embeds: [ item ],
                split: true,
                flags: "64",
           }
           }});        
                
            });
        });
});
}
}

  if(interaction.data.type === 3){
   let command = interaction.data.name.toLowerCase()
   let target = guild.members.cache.get(interaction.data.resolved.messages[interaction.data.target_id].author.id)
   let roller = target.roles
if (command === 'adk') {
  if (!ayar.muteciRolleri.some(rol => member.roles.cache.has(rol)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Bunu yapmak için yetkin yeterli değil!`,
    flags: "64",
}
}});  
let uye = target
if (uye.id === member.id) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Kendine mute atamazsın!`,
  flags: "64",
}
}}); 

if (uye.user.bot) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Botlara mute atamazsın!`,
  flags: "64",
}
}}); 
if (member.roles.highest.position <= roller.highest.position && !ayar.sahip.some(id => member.id === id) && !ayar.soruncozucu.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Mute atmak istediğin kişi senden üstün!`,
  flags: "64",
}
}}); 
  if (banLimitleri.get(member.id) >= ayar.mutelimit && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Mute atmak için limite ulaştın!`,
    flags: "64",
}
}});  
  const cezaNumara = await client.cezaNumara();
  let sure = "20m";
  let reason = "[AUTO] Ailevi Değerlere Küfür (ADK)";
  const atilisTarihi = Date.now();
  const bitisTarihi = Date.now() + ms(sure);
  let newPenalty = new Penalty({
    sunucuID: ayar.sunucuID,
    uyeID: uye.id,
    yetkiliID: member.id,
    cezaTuru: 'CHAT-MUTE',
    cezaSebebi: reason,
    atilmaTarihi: atilisTarihi,
    bitisTarihi: bitisTarihi,
});
uye.roles.add(ayar.muteRolu).catch(console.error);
client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `${uye} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\` boyunca **${reason}** sebebiyle chat kanallarında susturuldu!`,
  flags: "64",
}
}});
client.channels.cache.find(c => c.name === ayar.muteLogKanali).send(new MessageEmbed().setColor('f39c12').setDescription(`Engelleyen : ${member} \`(${member.id})\`\nEngellenen: ${uye} \`(${uye.id})\`\nSebep: ${reason}\nSüre: ${new Date(bitisTarihi).toTurkishFormatDate()} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\`\nCeza-i İşlem: Chat Mute \`(${cezaNumara})\``)).catch(console.error);

newPenalty.save();

banLimitleri.set(member.id, (Number(banLimitleri.get(member.id) || 0))+1);
}

if (command === 'dda') {
  if (!ayar.muteciRolleri.some(rol => member.roles.cache.has(rol)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Bunu yapmak için yetkin yeterli değil!`,
    flags: "64",
}
}});  
let uye = target
if (uye.id === member.id) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Kendine mute atamazsın!`,
  flags: "64",
}
}}); 

if (uye.user.bot) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Botlara mute atamazsın!`,
  flags: "64",
}
}}); 
if (member.roles.highest.position <= roller.highest.position && !ayar.sahip.some(id => member.id === id) && !ayar.soruncozucu.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Mute atmak istediğin kişi senden üstün!`,
  flags: "64",
}
}}); 
  if (banLimitleri.get(member.id) >= ayar.mutelimit && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Mute atmak için limite ulaştın!`,
    flags: "64",
}
}});  
  const cezaNumara = await client.cezaNumara();
  let sure = "2h";
  let reason = "[AUTO] Dini Değerlerle Alay (DDA)";
  const atilisTarihi = Date.now();
  const bitisTarihi = Date.now() + ms(sure);
  let newPenalty = new Penalty({
    sunucuID: ayar.sunucuID,
    uyeID: uye.id,
    yetkiliID: member.id,
    cezaTuru: 'CHAT-MUTE',
    cezaSebebi: reason,
    atilmaTarihi: atilisTarihi,
    bitisTarihi: bitisTarihi,
});
uye.roles.add(ayar.muteRolu).catch(console.error);
client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `${uye} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\` boyunca **${reason}** sebebiyle chat kanallarında susturuldu!`,
  flags: "64",
}
}});
client.channels.cache.find(c => c.name === ayar.muteLogKanali).send(new MessageEmbed().setColor('f39c12').setDescription(`Engelleyen : ${member} \`(${member.id})\`\nEngellenen: ${uye} \`(${uye.id})\`\nSebep: ${reason}\nSüre: ${new Date(bitisTarihi).toTurkishFormatDate()} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\`\nCeza-i İşlem: Chat Mute \`(${cezaNumara})\``)).catch(console.error);

newPenalty.save();

banLimitleri.set(member.id, (Number(banLimitleri.get(member.id) || 0))+1);
}

if (command === 'kışkırtma') {
  if (!ayar.muteciRolleri.some(rol => member.roles.cache.has(rol)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Bunu yapmak için yetkin yeterli değil!`,
    flags: "64",
}
}});  
let uye = target
if (uye.id === member.id) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Kendine mute atamazsın!`,
  flags: "64",
}
}}); 

if (uye.user.bot) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Botlara mute atamazsın!`,
  flags: "64",
}
}}); 
if (member.roles.highest.position <= roller.highest.position && !ayar.sahip.some(id => member.id === id) && !ayar.soruncozucu.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Mute atmak istediğin kişi senden üstün!`,
  flags: "64",
}
}}); 
  if (banLimitleri.get(member.id) >= ayar.mutelimit && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Mute atmak için limite ulaştın!`,
    flags: "64",
}
}});  
  const cezaNumara = await client.cezaNumara();
  let sure = "5m";
  let reason = "[AUTO] Kışkırtma";
  const atilisTarihi = Date.now();
  const bitisTarihi = Date.now() + ms(sure);
  let newPenalty = new Penalty({
    sunucuID: ayar.sunucuID,
    uyeID: uye.id,
    yetkiliID: member.id,
    cezaTuru: 'CHAT-MUTE',
    cezaSebebi: reason,
    atilmaTarihi: atilisTarihi,
    bitisTarihi: bitisTarihi,
});
uye.roles.add(ayar.muteRolu).catch(console.error);
client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `${uye} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\` boyunca **${reason}** sebebiyle chat kanallarında susturuldu!`,
  flags: "64",
}
}});
client.channels.cache.find(c => c.name === ayar.muteLogKanali).send(new MessageEmbed().setColor('f39c12').setDescription(`Engelleyen : ${member} \`(${member.id})\`\nEngellenen: ${uye} \`(${uye.id})\`\nSebep: ${reason}\nSüre: ${new Date(bitisTarihi).toTurkishFormatDate()} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\`\nCeza-i İşlem: Chat Mute \`(${cezaNumara})\``)).catch(console.error);

newPenalty.save();

banLimitleri.set(member.id, (Number(banLimitleri.get(member.id) || 0))+1);
}

if (command === 'küfür') {
  if (!ayar.muteciRolleri.some(rol => member.roles.cache.has(rol)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Bunu yapmak için yetkin yeterli değil!`,
    flags: "64",
}
}});  
let uye = target
if (uye.id === member.id) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Kendine mute atamazsın!`,
  flags: "64",
}
}}); 

if (uye.user.bot) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Botlara mute atamazsın!`,
  flags: "64",
}
}}); 
if (member.roles.highest.position <= roller.highest.position && !ayar.sahip.some(id => member.id === id) && !ayar.soruncozucu.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Mute atmak istediğin kişi senden üstün!`,
  flags: "64",
}
}}); 
  if (banLimitleri.get(member.id) >= ayar.mutelimit && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Mute atmak için limite ulaştın!`,
    flags: "64",
}
}});  
  const cezaNumara = await client.cezaNumara();
  let sure = "15m";
  let reason = "[AUTO] Küfür";
  const atilisTarihi = Date.now();
  const bitisTarihi = Date.now() + ms(sure);
  let newPenalty = new Penalty({
    sunucuID: ayar.sunucuID,
    uyeID: uye.id,
    yetkiliID: member.id,
    cezaTuru: 'CHAT-MUTE',
    cezaSebebi: reason,
    atilmaTarihi: atilisTarihi,
    bitisTarihi: bitisTarihi,
});
uye.roles.add(ayar.muteRolu).catch(console.error);
client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `${uye} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\` boyunca **${reason}** sebebiyle chat kanallarında susturuldu!`,
  flags: "64",
}
}});
client.channels.cache.find(c => c.name === ayar.muteLogKanali).send(new MessageEmbed().setColor('f39c12').setDescription(`Engelleyen : ${member} \`(${member.id})\`\nEngellenen: ${uye} \`(${uye.id})\`\nSebep: ${reason}\nSüre: ${new Date(bitisTarihi).toTurkishFormatDate()} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\`\nCeza-i İşlem: Chat Mute \`(${cezaNumara})\``)).catch(console.error);

newPenalty.save();

banLimitleri.set(member.id, (Number(banLimitleri.get(member.id) || 0))+1);
}

if (command === 'ddk') {
  if (!ayar.jailciRolleri.some(rol => member.roles.cache.has(rol)) && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Bunu yapmak için yetkin yeterli değil!`,
    flags: "64",
}
}});  
let uye = target
if (uye.id === member.id) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Kendini cezalandıramazsın!`,
  flags: "64",
}
}}); 

if (uye.user.bot) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Botları cezalandıramazsın!`,
  flags: "64",
}
}}); 
if (member.roles.highest.position <= roller.highest.position && !ayar.sahip.some(id => member.id === id) && !ayar.soruncozucu.some(role => member.roles.cache.has(role))) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `Cezalandırmak istediğin kişi senden üstün!`,
  flags: "64",
}
}}); 
  if (banLimitleri.get(member.id) >= ayar.jail && !ayar.sahipRolu.some(role => member.roles.cache.has(role)) && !ayar.sahip.some(id => member.id === id)) return client.api.interactions(interaction.id, interaction.token).callback.post({data: {
    type: 4,
    data: {
    content: `Jail atmak için limite ulaştın!`,
    flags: "64",
}
}});  
  let rollerr = uye.roles.cache.map(x => x.id);
  let adı = uye.displayName
  const cezaNumara = await client.cezaNumara();
  let sure = "7d";
  let reason = "[AUTO] Dini Değerlere Küfür (DDK)";
  const atilisTarihi = Date.now();
  const bitisTarihi = Date.now() + ms(sure);
  let newPenalty = new Penalty({
    sunucuID: ayar.sunucuID,
        uyeID: uye.id,
        yetkiliID: member.id,
        cezaTuru: "TEMP-JAIL",
        cezaSebebi: reason,
        atilmaTarihi: atilisTarihi,
        bitisTarihi: bitisTarihi,
        yetkiler: rollerr,
        adı: adı
});
if(uye.voice.channelID) await uye.voice.kick().catch();
await uye.setNickname(`${ayar.ikinciTag} Mahkum`)
await uye.roles.set(uye.roles.cache.has(ayar.boosterRolu) ? [ayar.jailRolu, ayar.boosterRolu] : [ayar.jailRolu]).catch(() => {
  return undefined;
});  
client.api.interactions(interaction.id, interaction.token).callback.post({data: {
  type: 4,
  data: {
  content: `${uye} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\` boyunca **${reason}** sebebiyle cezalandırıldı!`,
  flags: "64",
}
}});
client.channels.cache.find(c => c.name === ayar.muteLogKanali).send(new MessageEmbed().setColor('f39c12').setDescription(`Engelleyen : ${member} \`(${member.id})\`\nEngellenen: ${uye} \`(${uye.id})\`\nSebep: ${reason}\nSüre: ${new Date(bitisTarihi).toTurkishFormatDate()} \`(${moment.duration(ms(sure)).format('D [gün,] H [saat,] m [dakika]')})\`\nCeza-i İşlem: Temp Jail \`(${cezaNumara})\``)).catch(console.error);

newPenalty.save();

banLimitleri.set(member.id, (Number(banLimitleri.get(member.id) || 0))+1);
}
  }
})
}
module.exports.configuration = {
  name: "ready"
}


