﻿const { MessageEmbed } = require("discord.js");
const Penalty = require('../Models/Penalty.js');
const Cezapuan = require('../Models/cezapuanı.js');
const StatsModel = require("../Models/Stats.js");
const TaskModel = require("../Models/Task.js");
const client = global.client;
module.exports = () => {
  setInterval(async () => {
    await checkPenalties()
  }, 10000)
};
module.exports.configuration = {
  name: "ready"
};
async function checkPenalties() {
  let ayar = global.sunucuAyar;
  let guild = client.guilds.cache.get(ayar.sunucuID);
  let Penalties = await Penalty.find({ sunucuID: guild.id });
  Penalties = Penalties.filter(p => guild.members.cache.has(p.uyeID) && p.cezaTuru !== "KICK");
  let bitmisCezalar = Penalties.filter(p => p.bitisTarihi && p.bitisTarihi < Date.now());
  let surenCezalar = Penalties.filter(p => !p.bitisTarihi || p.bitisTarihi > Date.now());
  for (let i = 0; i < surenCezalar.length; i++) {
    let surenCeza = surenCezalar[i];
    if (!surenCeza) return;
    let uye = guild.members.cache.get(surenCeza.uyeID);
    if ((surenCeza.cezaTuru === "JAIL" || surenCeza.cezaTuru === "TEMP-JAIL") && !uye.roles.cache.has(ayar.jailRolu)) {
      uye.setNickname(`${ayar.ikinciTag} Mahkum`)
      if (!uye.roles.cache.has(ayar.jailRolu)) uye.roles.set(uye.roles.cache.has(ayar.boosterRolu) ? [ayar.boosterRolu, ayar.jailRolu] : [ayar.jailRolu]).catch(console.error);;
    };
    if ((surenCeza.cezaTuru === "BAN") && !uye.roles.cache.has(ayar.underworld)) {
      uye.setNickname(`${ayar.ikinciTag} BANLI`)
      if (!uye.roles.cache.has(ayar.underworld)) uye.roles.set(uye.roles.cache.has(ayar.boosterRolu) ? [ayar.boosterRolu, ayar.underworld] : [ayar.underworld]).catch(console.error);;
    };
    if ((surenCeza.cezaTuru === "FORCEBAN") && !uye.roles.cache.has(ayar.jailRolu)) {
      if (!uye.roles.cache.has(ayar.jailRolu)) uye.ban({ reason: "Forceban Algılandı." });
    };
    if (surenCeza.cezaTuru === "CHAT-MUTE" && !uye.roles.cache.has(ayar.muteRolu)) {
      if (!uye.roles.cache.has(ayar.muteRolu)) uye.roles.add(ayar.muteRolu).catch(console.error);;
    };
    if (surenCeza.cezaTuru === "UYARILDI1" && !uye.roles.cache.has(ayar.uyarı1)) {
      if (!uye.roles.cache.has(ayar.uyarı1)) uye.roles.add(ayar.uyarı1).catch(console.error);;
    };
    if (surenCeza.cezaTuru === "UYARILDI2" && !uye.roles.cache.has(ayar.uyarı2)) {
      if (!uye.roles.cache.has(ayar.uyarı2)) uye.roles.add(ayar.uyarı2).catch(console.error);;
    };
    if (surenCeza.cezaTuru === "VKCEZALI" && !uye.roles.cache.has(ayar.vkcezalırolu)) {
      if (!uye.roles.cache.has(ayar.vkcezalırolu)) uye.roles.add(ayar.vkcezalırolu).catch(console.error);;
    };
    if (surenCeza.cezaTuru === "DC-CEZALI" && !uye.roles.cache.has(ayar.dccezalırolu)) {
      if (!uye.roles.cache.has(ayar.dccezalırolu)) uye.roles.add(ayar.dccezalırolu).catch(console.error);;
    };
    if (surenCeza.cezaTuru === "REKLAM" && !uye.roles.cache.has(ayar.reklamRolu)) {
      uye.setNickname(`${ayar.ikinciTag} Reklamcı`)
      if (!uye.roles.cache.has(ayar.reklamRolu)) uye.roles.set([ayar.reklamRolu]).catch(console.error);;
    };
    if (surenCeza.cezaTuru === "VOICE-MUTE" && uye.voice.channelID && !uye.voice.serverMute) {
      if (uye.voice.channelID && !uye.voice.serverMute) uye.voice.setMute(true).catch(console.error);;
    };
  };
  for (let i = 0; i < bitmisCezalar.length; i++) {
    let bitmisCeza = bitmisCezalar[i];
    if (!bitmisCeza) return;
    let uye = guild.members.cache.get(bitmisCeza.uyeID);
    let surenJail = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && (c.cezaTuru === "JAIL" || c.cezaTuru === "TEMP-JAIL")).length;
    if ((bitmisCeza.cezaTuru === "JAIL" || bitmisCeza.cezaTuru === "TEMP-JAIL") && uye.roles.cache.has(ayar.jailRolu) && !surenJail) {
      uye.setNickname(`${ayar.ikinciTag} İsim | Yaş`)
      if (uye.roles.cache.has(ayar.jailRolu)) uye.roles.set(uye.roles.cache.has(ayar.boosterRolu) ? ayar.teyitsizRolleri.concat(ayar.boosterRolu) : ayar.teyitsizRolleri).catch(console.error);
    };
    let surenChatMute = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && c.cezaTuru === "CHAT-MUTE").length;
    if (bitmisCeza.cezaTuru === "CHAT-MUTE" && uye.roles.cache.has(ayar.muteRolu) && !surenChatMute) {
      if (uye.roles.cache.has(ayar.muteRolu)) uye.roles.remove(ayar.muteRolu).catch(console.error);;
    };
    
    let uyarı1 = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && c.cezaTuru === "UYARILDI1").length;
    if (bitmisCeza.cezaTuru === "UYARILDI1" && uye.roles.cache.has(ayar.muteRolu) && !uyarı1) {
      if (uye.roles.cache.has(ayar.uyarı1)) uye.roles.remove(ayar.uyarı1).catch(console.error);;
    };
    let dccezalı = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && c.cezaTuru === "DC-CEZALI").length;
    if (bitmisCeza.cezaTuru === "DC-CEZALI" && uye.roles.cache.has(ayar.muteRolu) && !dccezalı) {
      if (uye.roles.cache.has(ayar.dccezalırolu)) uye.roles.remove(ayar.dccezalırolu).catch(console.error);;
    };
    let vkcezalı = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && c.cezaTuru === "VKCEZALI").length;
    if (bitmisCeza.cezaTuru === "VKCEZALI" && uye.roles.cache.has(ayar.muteRolu) && !vkcezalı) {
      if (uye.roles.cache.has(ayar.vkcezalırolu)) uye.roles.remove(ayar.vkcezalırolu).catch(console.error);;
    };
    let uyarı2 = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && c.cezaTuru === "UYARILDI2").length;
    if (bitmisCeza.cezaTuru === "UYARILDI2" && uye.roles.cache.has(ayar.muteRolu) && !uyarı2) {
      if (uye.roles.cache.has(ayar.uyarı2)) uye.roles.remove(ayar.uyarı2).catch(console.error);;
    };
    let surenVoiceMute = surenCezalar.filter(c => c.uyeID === bitmisCeza.uyeID && c.cezaTuru === "VOICE-MUTE").length;
    if (bitmisCeza.cezaTuru === "VOICE-MUTE" && !surenVoiceMute && uye.displayName.includes('[ Muted ]')) {
    if (uye.manageable) uye.setNickname(uye.displayName.replace('[ Muted ] ', '')).catch(() => { return undefined; });
    }
    if (bitmisCeza.cezaTuru === "VOICE-MUTE" && uye.voice.channelID && uye.voice.serverMute && !surenVoiceMute) {
      if (uye.voice.channelID && uye.voice.serverMute) uye.voice.setMute(false).catch(() => {
        return undefined;
      });
    };
  };
};