const { Client, MessageEmbed, Intents, Collection, APIMessage } = require('discord.js');
require('discord-inline-reply');
const client = global.client = new Client({
  fetchAllMembers: true, ws: {
    intents: new Intents(Intents.ALL).remove([
      "GUILD_BANS",
      "GUILD_EMOJIS",
      "GUILD_INTEGRATIONS",
      "GUILD_INVITES",
      "GUILD_MESSAGE_TYPING",
      "DIRECT_MESSAGES",
      "DIRECT_MESSAGE_REACTIONS",
      "DIRECT_MESSAGE_TYPING"
    ])
  }
});
const sunucuAyar = global.sunucuAyar = require("../sunucuAyar.js");
const mongoose = require('mongoose');
mongoose.connect(sunucuAyar.mongodb, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false });
const Penalty = require('./Models/Penalty.js');
const moment = require('moment');
require('moment-duration-format');
require('moment-timezone');
moment.locale('tr');
const fs = require("fs");

const commands = global.commands = new Collection();
const aliases = global.aliases = new Collection();
global.client = client;
fs.readdir(__dirname + "/Commands", (err, files) => {
  if (err) return console.error(err);
  files = files.filter(file => file.endsWith(".js"));
  console.log(`${files.length} komut yüklenecek.`);
  files.forEach(file => {
    let prop = require(`./Commands/${file}`);
    if (!prop.configuration) return;
    if (typeof prop.onLoad === "function") prop.onLoad(client);
    commands.set(prop.configuration.name, prop);
    if (prop.configuration.aliases) prop.configuration.aliases.forEach(aliase => aliases.set(aliase, prop.configuration.name));
  });
});
fs.readdir(__dirname + "/Events", (err, files) => {
  if (err) return console.error(err);
  files.filter(file => file.endsWith(".js")).forEach(file => {
    let prop = require(`./Events/${file}`);
    if (!prop.configuration) return;
    client.on(prop.configuration.name, prop);
  });
});

client.convertDuration = (date) => {
  return moment.duration(date).format('H [saat,] m [dakika]');
};


Date.prototype.toTurkishFormatDate = function () {
  return moment.tz(this, "Europe/Istanbul").format('LLL');
};

client.cezaNumara = async function () {
  var cezaNo = await Penalty.countDocuments({ sunucuID: sunucuAyar.sunucuID });
  return cezaNo;
};

client.tarihHesapla = (date) => {
  return moment(date).fromNow();
};

client.splitEmbedWithDesc = async function (description, author = false, footer = false, features = false) {
  let embedSize = parseInt(`${description.length / 4096}`.split('.')[0]) + 1
  let embeds = new Array()
  for (var i = 0; i < embedSize; i++) {
    let desc = description.split("").splice(i * 4096, (i + 1) * 4096)
    let x = new MessageEmbed().setDescription(desc.join(""))
    if (i == 0 && author) x.setAuthor(author.name, author.icon ? author.icon : null)
    if (i == embedSize - 1 && footer) x.setFooter(footer.name, footer.icon ? footer.icon : null)
    if (i == embedSize - 1 && features && features["setTimestamp"]) x.setTimestamp(features["setTimestamp"])
    if (features) {
      let keys = Object.keys(features)
      keys.forEach(key => {
        if (key == "setTimestamp") return
        let value = features[key]
        if (i !== 0 && key == 'setColor') x[key](value[0])
        else if (i == 0) {
          if (value.length == 2) x[key](value[0], value[1])
          else x[key](value[0])
        }
      })
    }
    embeds.push(x)
  }
  return embeds
};

client.on("message", (message) => {
  let prefix = sunucuAyar.prefix.find(a => message.content.toLowerCase().startsWith(a));
  if (!prefix) return;
  if (message.author.bot || message.channel.type == "dm") return;
  let args = message.content.split(" ").slice(1);
  let command = message.content.split(" ")[0].slice(prefix.length);
  let bot = message.client;
  let ayar = sunucuAyar;
  let cmd = commands.get(command) || commands.get(aliases.get(command));
  if (cmd) {
    if (message.member.roles.cache.has(sunucuAyar.jailRolu) || sunucuAyar.teyitsizRolleri.some(rol => message.member.roles.cache.has(rol))) return;
    let permLevel = cmd.configuration.permLevel;
    if (permLevel == 1 && !sunucuAyar.sahipRolu.some(x => message.member.roles.cache.has(x)) && message.author.id !== message.guild.ownerID && !sunucuAyar.sahip.some(x => message.author.id === x)) return message.react("❌");
    if (permLevel == 2 && !message.member.hasPermission("ADMINISTRATOR") && !message.member.hasPermission("MANAGE_CHANNELS")) return message.react("❌");
    cmd.execute(bot, message, args, ayar, client.emojiler);
  };
});
client.login(sunucuAyar.token).then(x => console.log(`Bot ${client.user.tag} olarak giriş yaptı!`)).catch(err => console.error(`Bot giriş yapamadı | Hata: ${err}`));