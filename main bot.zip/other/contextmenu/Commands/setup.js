const { MessageEmbed } = require("discord.js");
const sunucuAyar = require('../../sunucuAyar.js');
const data = require('../../Models/sunucuAyar.js');

module.exports.execute = async (client, message, args, ayar, emoji) => {
    if (!sunucuAyar.sahip.some(id => message.author.id === id) && !sunucuAyar.kurulumcular.some(id => message.author.id === id)) return;
    let veri = await data.findOne({ sunucuID: message.guild.id })
    if (!veri) { veri = data.create({ sunucuID: message.guild.id }) }
    if (!args[0] || !["moderasyon", "yönetim", "yetkili", "cezalı", "info", "diğer"].some(c => args[0].includes(c))) {
        message.lineReply(new MessageEmbed()
        .setDescription(`
        \`\`\`
        GENEL
        ///////////////////////////////
        .setup moderasyon
        .setup yönetim
        .setup yetkili
        .setup cezalı
        .setup diğer
        .setup info
        \`\`\``)
        )
    }
    if (args[0] && args[0].includes('moderasyon')) {
        if (!args[1] || !["ban", "jail", "yargı", "mute", "timeout", "reklam", "kayıt"].some(c => args[1].includes(c))) {
            message.lineReply(new MessageEmbed()
            .setDescription(`
            \`\`\`
            MODERASYON
            ///////////////////////////////
            .setup moderasyon ban
            .setup moderasyon jail
            .setup moderasyon yargı
            .setup moderasyon mute
            .setup moderasyon timeout
            .setup moderasyon reklam
            .setup moderasyon kayıt
            \`\`\``)
            )
        }
        if (args[1] && args[1].includes('ban')) {
            if(!args[2] || !['rolü', 'limit', 'sorumlu', 'yetkili', 'log'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                BAN
                ///////////////////////////////
                .setup moderasyon ban rolü (banlanan kişiye verilecek rol)
                .setup moderasyon ban limit (bir yetkilinin ban komutunu kullanma limiti)
                .setup moderasyon ban sorumlu (banları açabilecek kişilerin sahip olacağı rol/rolleri sıralayabilirsiniz)
                .setup moderasyon ban yetkili (ban komutu kullanabilecek yetkililer)
                .setup moderasyon ban log (ban log kanalı)
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('rolü')) {
                const rol = message.mentions.roles.first() || message.guild.roles.cache.get(args[3])
                if(!args[3] || !rol) return message.lineReply('Bir rol belirtmedin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { underworld: rol.id }, { upsert: true })
                message.lineReply(`Ban rolü başarı ile ${rol} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('limit')) {
                const sayı = Number(args[3])
                if(!args[3] || !Number(args[3])) return message.lineReply('Bir sayı belirtmelisin ya da belirttiğin şey bir sayı değil!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { banLimit: sayı, unban: sayı }, { upsert: true })
                message.lineReply(`Ban limit başarı ile **${sayı}** olarak ayarlandı.`)               
            }
            if (args[2] && args[2].includes('sorumlu')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Sorumlu rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { bansorumlusu: roles }, { upsert: true })
                message.lineReply(`Ban sorumlu rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('yetkili')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { banciRolleri: roles }, { upsert: true })
                message.lineReply(`Ban yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('log')) {
                const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[3])
                if (!args[3] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                await data.updateOne({ sunucuID: message.guild.id }, { banLogKanali: kanal.name }, { upsert: true })
                message.lineReply(`Ban log kanalı başarı ile ${kanal} olarak ayarlandı!`)
            }
        }
        if (args[1] && args[1].includes('jail')) {
            if(!args[2] || !['rolü', 'limit', 'sorumlu', 'yetkili', 'log'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                JAİL
                ///////////////////////////////
                .setup moderasyon jail rolü (jaillenen kişiye verilecek rol)
                .setup moderasyon jail limit (bir yetkilinin jail komutunu kullanma limiti)
                .setup moderasyon jail sorumlu (jailleri açabilecek kişilerin sahip olacağı rol/rolleri sıralayabilirsiniz)
                .setup moderasyon jail yetkili (jail komutu kullanabilecek yetkililer)
                .setup moderasyon jail log (jail log kanalı)
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('rolü')) {
                const rol = message.mentions.roles.first() || message.guild.roles.cache.get(args[3])
                if(!args[3] || !rol) return message.lineReply('Bir rol belirtmedin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { jailRolu: rol.id }, { upsert: true })
                message.lineReply(`Jail rolü başarı ile ${rol} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('limit')) {
                const sayı = Number(args[3])
                if(!args[3] || !Number(args[3])) return message.lineReply('Bir sayı belirtmelisin ya da belirttiğin şey bir sayı değil!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { jail: sayı, unjail: sayı }, { upsert: true })
                message.lineReply(`Jail limit başarı ile **${sayı}** olarak ayarlandı.`)               
            }
            if (args[2] && args[2].includes('sorumlu')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Sorumlu rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { jailsorumlusu: roles }, { upsert: true })
                message.lineReply(`Jail sorumlu rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('yetkili')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { jailciRolleri: roles }, { upsert: true })
                message.lineReply(`Jail yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('log')) {
                const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[3])
                if (!args[3] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                await data.updateOne({ sunucuID: message.guild.id }, { jailLogKanali: kanal.name }, { upsert: true })
                message.lineReply(`Jail log kanalı başarı ile ${kanal} olarak ayarlandı!`)
            }
        }
        if (args[1] && args[1].includes('yargı')) {
            if(!args[2] || !['yetkili'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                YARGI
                ///////////////////////////////
                .setup moderasyon yargı yetkili (yargı komutu kullanabilecek yetkililer)
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('yetkili')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { ownerRolleri: roles }, { upsert: true })
                message.lineReply(`Yargı yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
        }
        if (args[1] && args[1].includes('mute')) {
            if(!args[2] || !['chat', 'ses'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                MUTE
                ///////////////////////////////
                .setup moderasyon mute chat
                .setup moderasyon mute ses
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('chat')) {
                if(!args[3] || !['rolü', 'limit', 'yetkili', 'log'].some(c => args[3].includes(c))) {
                    message.lineReply(new MessageEmbed()
                    .setDescription(`
                    \`\`\`
                    CHAT
                    ///////////////////////////////
                    .setup moderasyon mute chat rolü (mutelenen kişiye verilecek rol)
                    .setup moderasyon mute chat limit (bir yetkilinin mute komutunu kullanma limiti)
                    .setup moderasyon mute chat yetkili (mute komutu kullanabilecek yetkililer)
                    .setup moderasyon mute chat log (mute log kanalı)
                    \`\`\``)
                    )
                }
                if (args[3] && args[3].includes('rolü')) {
                    const rol = message.mentions.roles.first() || message.guild.roles.cache.get(args[4])
                    if (!args[4] || !rol) return message.lineReply('Bir rol belirtmedin!').then(c => c.delete({ timeout: 7500 }))
                    await data.updateOne({ sunucuID: message.guild.id }, { muteRolu: rol.id }, { upsert: true })
                    message.lineReply(`Chat mute rolü başarı ile ${rol} olarak ayarlandı.`)
                }
                if (args[3] && args[3].includes('limit')) {
                    const sayı = Number(args[4])
                    if (!args[4] || !Number(args[4])) return message.lineReply('Bir sayı belirtmedin ya da belirttiğin şey bir sayı değil!').then(c => c.delete({timeout: 7500}))
                    await data.updateOne({ sunucuID: message.guild.id}, { muteLimit: sayı }, { upsert: true })
                    message.lineReply(`Chat mute limiti başarı ile ${sayı} olarak ayarlandı.`)
                }
                if (args[3] && args[3].includes('yetkili')) {
                    const roles = message.mentions.roles.map(c => c.id)
                    if (!args[4] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                    await data.updateOne({ sunucuID: message.guild.id }, { muteciRolleri: roles }, { upsert: true })
                    message.lineReply(`Chat mute yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
                }
                if (args[3] && args[3].includes('log')) {
                    const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[4])
                    if (!args[4] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                    await data.updateOne({ sunucuID: message.guild.id }, { muteLogKanali: kanal.name }, { upsert: true })
                    message.lineReply(`Chat mute log kanalı başarı ile ${kanal} olarak ayarlandı!`)
                }
            }
            if (args[2] && args[2].includes('ses')) {
                if(!args[3] || !['rolü', 'limit', 'yetkili', 'log'].some(c => args[3].includes(c))) {
                    message.lineReply(new MessageEmbed()
                    .setDescription(`
                    \`\`\`
                    SES
                    ///////////////////////////////
                    .setup moderasyon mute ses yetkili (mute komutu kullanabilecek yetkililer)
                    .setup moderasyon mute ses log (mute log kanalı)
                    \`\`\``)
                    )
                }
                if (args[3] && args[3].includes('yetkili')) {
                    const roles = message.mentions.roles.map(c => c.id)
                    if (!args[4] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                    await data.updateOne({ sunucuID: message.guild.id }, { sesMuteciRolleri: roles }, { upsert: true })
                    message.lineReply(`Ses mute yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
                }
                if (args[3] && args[3].includes('log')) {
                    const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[4])
                    if (!args[4] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                    await data.updateOne({ sunucuID: message.guild.id }, { sesMuteLogKanali: kanal.name }, { upsert: true })
                    message.lineReply(`Ses mute log kanalı başarı ile ${kanal} olarak ayarlandı!`)
                }
            }
        }
        if (args[1] && args[1].includes('timeout')) {
            if(!args[2] || !['yetkili','limit'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                TİMEOUT
                ///////////////////////////////
                .setup moderasyon timeout limit (bir yetkilinin timeout komutunu kullanma limiti)
                .setup moderasyon timeout yetkili (timeout komutu kullanabilecek yetkililer)
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('limit')) {
                const sayı = Number(args[3])
                if(!args[3] || !Number(args[3])) return message.lineReply('Bir sayı belirtmelisin ya da belirttiğin şey bir sayı değil!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { timeoutlimit: sayı }, { upsert: true })
                message.lineReply(`Timeout limit başarı ile **${sayı}** olarak ayarlandı.`)               
            }
            if (args[2] && args[2].includes('yetkili')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { timeoutçular: roles }, { upsert: true })
                message.lineReply(`Timeout yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
        }
        if (args[1] && args[1].includes('reklam')) {
            if(!args[2] || !['rolü', 'limit', 'yetkili', 'log'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                REKLAM
                ///////////////////////////////
                .setup moderasyon reklam rolü (reklamlanan kişiye verilecek rol)
                .setup moderasyon reklam limit (bir yetkilinin reklam komutunu kullanma limiti)
                .setup moderasyon reklam yetkili (reklam komutu kullanabilecek yetkililer)
                .setup moderasyon reklam log (reklam log kanalı)
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('rolü')) {
                const rol = message.mentions.roles.first() || message.guild.roles.cache.get(args[3])
                if(!args[3] || !rol) return message.lineReply('Bir rol belirtmedin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { reklamRol: rol.id }, { upsert: true })
                message.lineReply(`Jail rolü başarı ile ${rol} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('limit')) {
                const sayı = Number(args[3])
                if(!args[3] || !Number(args[3])) return message.lineReply('Bir sayı belirtmelisin ya da belirttiğin şey bir sayı değil!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { reklam: sayı }, { upsert: true })
                message.lineReply(`Reklam limit başarı ile **${sayı}** olarak ayarlandı.`)               
            }
            if (args[2] && args[2].includes('yetkili')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { reklamciRolu: roles }, { upsert: true })
                message.lineReply(`Reklam yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('log')) {
                const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[3])
                if (!args[3] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                await data.updateOne({ sunucuID: message.guild.id }, { reklamLogKanali: kanal.name }, { upsert: true })
                message.lineReply(`Reklam log kanalı başarı ile ${kanal} olarak ayarlandı!`)
            }
        }
        if (args[1] && args[1].includes('kayıt')) {
            if(!args[2] || !['erkek', 'kız', 'kayıtsız', 'chat', 'kanal', 'welcome', 'yetkili'].some(c => args[2].includes(c))) {
                message.lineReply(new MessageEmbed()
                .setDescription(`
                \`\`\`
                REKLAM
                ///////////////////////////////
                .setup moderasyon kayıt erkek (erkek rolleri)
                .setup moderasyon kayıt kız (kız rolleri)
                .setup moderasyon kayıt kayıtsız (sunucuya giren kişilere verilecek kayıtsız rolleri)
                .setup moderasyon kayıt chat (sunucunun chati)
                .setup moderasyon kayıt kanal (kayıt kanalı)
                .setup moderasyon kayıt welcome (hoşgeldin mesajı atılacak kanal)
                .setup moderasyon kayıt yetkili (kayıt komutu kullanabilecek yetkililer)
                \`\`\``)
                )
            }
            if (args[2] && args[2].includes('erkek')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Erkek rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { erkekRolleri: roles }, { upsert: true })
                message.lineReply(`Erkek rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('kız')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Kız rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { kizRolleri: roles }, { upsert: true })
                message.lineReply(`Kız rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('kayıtsız')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Kayıtsız rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { teyitsizRolleri: roles }, { upsert: true })
                message.lineReply(`Kayıtsız rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
            if (args[2] && args[2].includes('chat')) {
                const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[3])
                if (!args[3] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                await data.updateOne({ sunucuID: message.guild.id }, { chatKanali: kanal.name }, { upsert: true })
                message.lineReply(`Chat kanalı başarı ile ${kanal} olarak ayarlandı!`)
            }
            if (args[2] && args[2].includes('kanal')) {
                const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[3])
                if (!args[3] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                await data.updateOne({ sunucuID: message.guild.id }, { kayıtKanali: kanal.name }, { upsert: true })
                message.lineReply(`Kayıt kanalı başarı ile ${kanal} olarak ayarlandı!`)
            }
            if (args[2] && args[2].includes('welcome')) {
                const kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[3])
                if (!args[3] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
                await data.updateOne({ sunucuID: message.guild.id }, { teyitKanali: kanal.name }, { upsert: true })
                message.lineReply(`Welcome kanalı başarı ile ${kanal} olarak ayarlandı!`)
            }
            if (args[2] && args[2].includes('yetkili')) {
                const roles = message.mentions.roles.map(c => c.id)
                if(!args[3] || !roles) return message.lineReply('Yetkili rolleri belirtmelisin!').then(c => c.delete({ timeout: 7500 }))
                await data.updateOne({ sunucuID: message.guild.id }, { teyitciRolleri: roles }, { upsert: true })
                message.lineReply(`Kayıt yetkili rolleri ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
            }
        }
    }
};
module.exports.configuration = {
  name: "setup",
  aliases: ['setup'],
  usage: "setup",
  description: "Setup işte.",
  permLevel: 0
};