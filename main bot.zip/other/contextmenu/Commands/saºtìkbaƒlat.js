const sunucuAyar = require('../../sunucuAyar.js')
const data = require('../../Models/sunucuAyar.js')

module.exports.execute = async (client, message, args, emoji) => {
    if (!sunucuAyar.sahip.some(id => message.author.id === id) && !sunucuAyar.kurulumcular.some(id => message.author.id === id)) return;
    let ayar = await data.findOne({ sunucuID: message.guild.id })
    if (!ayar) return message.lineReply('.setup komutu ile bu komutu kurmalısın.').then(c => c.delete({timeout: 7500}))
    message.lineReply('Başlatıyorum.')
    client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "git",
        "type":"2",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "çek",
        "type":"2",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "sicil",
        "type":"2",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "banner",
        "type":"2",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "avatar",
        "type":"2",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "ADK",
        "type":"3",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "DDK",
        "type":"3",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "DDA",
        "type":"3",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "Kışkırtma",
        "type":"3",
      }
      })
      
      client.api.applications(client.user.id).guilds(ayar.sunucuID).commands.post({data: {
        "name": "Küfür",
        "type":"3",
      }
      })
      
};
module.exports.configuration = {
  name: "sağtıkbaşlat",
  aliases: [],
  usage: "sağtıkbaşlat",
  description: "Context başlat işte.",
  permLevel: 0
};