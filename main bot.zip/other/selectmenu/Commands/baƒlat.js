const { MessageEmbed } = require("discord.js");
const Penalty = require('../Models/Penalty.js');
const sunucuAyar = require('../../sunucuAyar.js')
const data = require('../../Models/sunucuAyar.js')
var banLimitleri = new Map();

module.exports.execute = async (client, message, args, emoji) => {
    if (!sunucuAyar.sahip.some(id => message.author.id === id) && !sunucuAyar.kurulumcular.some(id => message.author.id === id)) return;
    let ayar = await data.findOne({ sunucuID: message.guild.id })
    if (!ayar || !message.guild.channels.cache.has(ayar.renkKanalID) || !message.guild.channels.cache.has(ayar.burçKanalID) || !message.guild.channels.cache.has(ayar.ilişkiKanalID) || !message.guild.channels.cache.has(ayar.etkinlikKanalID) || !message.guild.channels.cache.has(ayar.oyunKanalID)) return message.lineReply('.setup komutu ile bu komutu kurmalısın.').then(c => c.delete({timeout: 7500}))
    message.lineReply('Başlatıyorum.')
    client.api.channels(ayar.renkKanalID).messages.post({ data: { 
        "content": "Buradan görünmek istediğiniz rengi seçebilirsiniz.",
        "components": [
          {
            "type": 1,
            "components": [
                {
                  
                  "type": 3,
                  "custom_id": "renk_menu",
                  "default": false,
                  "options":[
                    {
                      "label": "Mavi",
                      "value": "mavi",
                      "description": "Bu rengi seçerseniz kullanıcı adınız chat ve üye listesinde mavi gözükecektir.",
                      "emoji": {
                        "name": "klowragem", 
                        "id": "915906447068516353"
                      }
                    },
                    {
                      "label": "Yeşil",
                      "value": "yeşil",
                      "description": "Bu rengi seçerseniz kullanıcı adınız chat ve üye listesinde yeşil gözükecektir.",
                      "emoji": {
                        "name": "klowrakiwi", 
                        "id": "915906448268095558"
                      }
                    },
                    {
                      "label": "Mor",
                      "value": "mor",
                      "description": "Bu rengi seçerseniz kullanıcı adınız chat ve üye listesinde mor gözükecektir.",
                      "emoji": {
                        "name": "klowraberry", 
                        "id": "915906448427450398"
                      }
                    },
                    {
                      "label": "Kırmızı",
                      "value": "kırmızı",
                      "description": "Bu rengi seçerseniz kullanıcı adınız chat ve üye listesinde kırmızı gözükecektir.",
                      "emoji": {
                        "name": "klowrakiraz2", 
                        "id": "915906444958785536"
                      }
                    },
                    {
                      "label": "Turuncu",
                      "value": "turuncu",
                      "description": "Bu rengi seçerseniz kullanıcı adınız chat ve üye listesinde turuncu gözükecektir.",
                      "emoji": {
                        "name": "klowraportakal", 
                        "id": "915906444057014302"
                      }
                    },
                    {
                      "label": "Temizle",
                      "value": "temizle",
                      "description": "Bu seçenek üzerinizdeki rolü temizlemenize yarar.",
                      "emoji": {
                        "name": "klowratrash", 
                        "id": "915906447508906005"
                      }
                    },
                  ],
                  "placeholder": "Renk seç...",
                  "min_values": 1,
                  "max_values": 1
              },
            ]
          }
        ],
        }
        })
      client.api.channels(ayar.burçKanalID).messages.post({ data: { 
        "content": "Buradan burcunuzu seçebilirsiniz.",
        "components": [
          {
            "type": 1,
            "components": [
                {
                  
                  "type": 3,
                  "custom_id": "burc_menu",
                  "default": false,
                  "options":[
                    {
                      "label": "Yengeç",
                      "value": "yengec",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc9", 
                        "id": "848959492850974754"
                      }
                    },
                    {
                      "label": "Yay",
                      "value": "yay",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc6", 
                        "id": "848958520488493056"
                      }
                    },
                    {
                      "label": "Terazi",
                      "value": "terazi",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc4", 
                        "id": "848957779523403816"
                      }
                    },
                    {
                      "label": "Oğlak",
                      "value": "oglak",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc5", 
                        "id": "848958161280696370"
                      }
                    },
                    {
                      "label": "Kova",
                      "value": "kova",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc1", 
                        "id": "848925175093526558"
                      }
                    },
                    {
                      "label": "Koç",
                      "value": "koc",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc12", 
                        "id": "848960960425099315"
                      }
                    },
                    {
                      "label": "Boğa",
                      "value": "boga",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc11", 
                        "id": "848960542176444486"
                      }
                    },
                    {
                      "label": "İkizler",
                      "value": "ikizler",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc10", 
                        "id": "848960046024359987"
                      }
                    },
                    {
                      "label": "Balık",
                      "value": "balık",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc3", 
                        "id": "848957147277951037"
                      }
                    },
                    {
                      "label": "Aslan",
                      "value": "aslan",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc7", 
                        "id": "848958688450052117"
                      }
                    },
                    {
                      "label": "Akrep",
                      "value": "akrep",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc2", 
                        "id": "848925353518170153"
                      }
                    },
                    {
                      "label": "Başak",
                      "value": "basak",
                      "description": "Bu rol sizin burcunuz olarak gözükecektir.",
                      "emoji": {
                        "name": "ALERUS_burc8", 
                        "id": "848959245760331838"
                      }
                    },
                    {
                      "label": "Temizle",
                      "value": "temizle",
                      "description": "Bu seçenek üzerinizdeki rolü temizlemenize yarar.",
                      "emoji": {
                      "name": "klowratrash", 
                      "id": "915906447508906005"
                      }
                    },
                  ],
                  "placeholder": "Burç seç...",
                  "min_values": 1,
                  "max_values": 1
              },
            ]
          }
        ],
        }
        })
      client.api.channels(ayar.ilişkiKanalID).messages.post({ data: { 
        "content": "Buradan ilişki durumunuzu seçebilirsiniz.",
        "components": [
          {
            "type": 1,
            "components": [
                {
                  
                  "type": 3,
                  "custom_id": "iliski_menu",
                  "default": false,
                  "options":[
                    {
                      "label": "İlişkim var.",
                      "value": "lovers",
                      "description": "Bu rol diğer üyelere ilişkinizin olduğunu gösterir.",
                      "emoji": {
                        "name": "LOVER", 
                        "id": "850131934633525278"
                      }
                    },
                    {
                      "label": "İlişkim yok.",
                      "value": "alone",
                      "description": "Bu rol diğer üyelere ilişkinizin olmadığını gösterir.",
                      "emoji": {
                        "name": "ALONE", 
                        "id": "850132192414793738"
                      }
                    },
                    {
                      "label": "LGBT.",
                      "value": "lgbt",
                      "description": "Bu rol diğer üyelere lgbt destekçisi olduğunuzu gösterir.",
                      "emoji": {
                        "name": "LGBT", 
                        "id": "850132372513882162"
                      }
                    },
                    {
                      "label": "İlişki istemiyorum.",
                      "value": "satisfied",
                      "description": "Bu rol diğer üyelere ilişki istemediğinizi gösterir.",
                      "emoji": {
                        "name": "BB", 
                        "id": "903905293740691476"
                      }
                    },
                    {
                      "label": "Temizle",
                      "value": "temizle",
                      "description": "Bu seçenek üzerinizdeki rolü temizlemenize yarar.",
                      "emoji": {
                        "name": "klowratrash", 
                        "id": "915906447508906005"
                      }
                    },
                  ],
                  "placeholder": "İlişki rolü seç...",
                  "min_values": 1,
                  "max_values": 1
              },
            ]
          }
        ],
        }
        })
      client.api.channels(ayar.etkinlikKanalID).messages.post({ data: { 
        "content": "Buradan etkinlik rollerinizi seçebilirsiniz.",
        "components": [
          {
            "type": 1,
            "components": [
                {
                  
                  "type": 3,
                  "custom_id": "etkinlik_menu",
                  "default": false,
                  "options":[
                    {
                      "label": "Çekiliş",
                      "value": "cekilis",
                      "description": "Çekilişlerde bildirim almanızı sağlar.",
                      "emoji": {
                        "name": "klowragift", 
                        "id": "915906440537997322"
                      }
                    },
                    {
                      "label": "Vampir Köylü",
                      "value": "vk",
                      "description": "Vampir Köylü etkinliklerine katılım sağlamanıza yarar.",
                      "emoji": {
                        "name": "klowravk", 
                        "id": "915906444447080449"
                      }
                    },
                    {
                      "label": "Doğruluk Cesaret",
                      "value": "dc",
                      "description": "Doğruluk Cesaret etkinliklerine katılım sağlamanıza yarar.",
                      "emoji": {
                        "name": "klowradc", 
                        "id": "915906445680193546"
                      }
                    },
                    {
                      "label": "Temizle",
                      "value": "temizle",
                      "description": "Bu seçenek üzerinizdeki rolleri temizlemenize yarar.",
                      "emoji": {
                        "name": "klowratrash", 
                        "id": "915906447508906005"
                      }
                    },
                  ],
                  "placeholder": "Etkinlik rollerini seç...",
                  "min_values": 1,
                  "max_values": 3
              },
            ]
          }
        ],
        }
        })
      client.api.channels(ayar.oyunKanalID).messages.post({ data: { 
        "content": "Buradan oyun rollerinizi seçebilirsiniz.",
        "components": [
          {
            "type": 1,
            "components": [
                {
                  
                  "type": 3,
                  "custom_id": "oyun_menu",
                  "default": false,
                  "options":[
                    {
                      "label": "GTA V",
                      "value": "gtav",
                      "description": "Gta 5 oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_GTAV", 
                        "id": "849063482356006923"
                      }
                    },
                    {
                      "label": "CS GO",
                      "value": "csgo",
                      "description": "Csgo oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_CSGO", 
                        "id": "849062494307876914"
                      }
                    },
                    {
                      "label": "PUBG",
                      "value": "pubg",
                      "description": "Pubg oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_PUBG", 
                        "id": "849061625734234132"
                      }
                    },
                    {
                      "label": "LOL",
                      "value": "lol",
                      "description": "Lol oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_LOL", 
                        "id": "849060820012630026"
                      }
                    },
                    {
                      "label": "VALORANT",
                      "value": "valorant",
                      "description": "Valorant oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_VALORANT", 
                        "id": "849059607959830559"
                      }
                    },
                    {
                      "label": "MİNECRAFT",
                      "value": "minecraft",
                      "description": "Minecraft oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_MC", 
                        "id": "849056837311660083"
                      }
                    },
                    {
                      "label": "FORTNİTE",
                      "value": "fortnite",
                      "description": "Fortnite oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_FORTNITE", 
                        "id": "849049998607122452"
                      }
                    },
                    {
                      "label": "COD",
                      "value": "cod",
                      "description": "Call of duty oyun rolünü alırsınız.",
                      "emoji": {
                        "name": "OYUN_COD", 
                        "id": "849053064052473906"
                      }
                    },
                    {
                      "label": "Temizle",
                      "value": "temizle",
                      "description": "Bu seçenek üzerinizdeki rolleri temizlemenize yarar.",
                      "emoji": {
                        "name": "klowratrash", 
                        "id": "915906447508906005"
                      }
                    },
                  ],
                  "placeholder": "Oyun rollerini seç...",
                  "min_values": 1,
                  "max_values": 8
              },
            ]
          }
        ],
        }
        })
};
module.exports.configuration = {
  name: "başlat",
  aliases: [],
  usage: "başlat",
  description: "Başlat işte.",
  permLevel: 0
};