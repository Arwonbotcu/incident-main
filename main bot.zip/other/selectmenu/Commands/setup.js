const { MessageEmbed } = require("discord.js");
const sunucuAyar = require('../../sunucuAyar.js');
const data = require('../../Models/sunucuAyar.js');

module.exports.execute = async (client, message, args, ayar, emoji) => {
    if (!sunucuAyar.sahip.some(id => message.author.id === id) && !sunucuAyar.kurulumcular.some(id => message.author.id === id)) return;
    let veri = await data.findOne({ sunucuID: message.guild.id })
    if (!veri) { veri = data.create({ sunucuID: message.guild.id }) }
    if (!args[0]) {
        message.lineReply(new MessageEmbed()
        .setDescription(`
        \`\`\`
        ROL SEÇME
        ///////////////////////////////
        .setup renk
        .setup ilişki
        .setup burç
        .setup oyun
        .setup etkinlik
        \`\`\``)
        )
    }
    if (args[0] && args[0].includes('renk')) {
        if (!args[1]) {
            message.lineReply(new MessageEmbed()
           .setDescription(`
           \`\`\`
           RENK SEÇME
           ///////////////////////////////
           .setup renk kanal #kanaletiket
           .setup renk rolleri @renkrolü1 @renkrolü2 @renkrolü3 (ne kadar varsa sırası ile etiketleyiniz)
           .setup renk mavi @maviroletiket
           .setup renk kırmızı @kırmızıroletiket
           .setup renk turuncu @turunroletiket
           .setup renk mor @morroletiket
           .setup renk yeşil @yeşilroletiket
           \`\`\``)
           )
        }
        if (args[1] && args[1].includes('kanal')) {
            let kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[2])
            if (!args[2] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { renkKanalID: kanal.id }, { upsert: true })
            message.lineReply(`Renk kanal menüsü başarı ile ${kanal} olarak ayarlandı!`)
        }
        if (args[1] && args[1].includes('rolleri')) {
            let roles = message.mentions.roles.map(c => c.id)
            if (!args[2] || !roles) return message.lineReply('Rollerini belirtmelisin!')
            await data.updateOne({ sunucuID: message.guild.id }, { renkler: roles }, { upsert: true })
            message.lineReply(`Renk rolleri menüsü başarı ile ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('mavi')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Mavi rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { mavirenk: role.id }, { upsert: true })
            message.lineReply(`Renk menü mavi rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('kırmızı')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Kırmızı rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { kırmızırenk: role.id }, { upsert: true })
            message.lineReply(`Renk menü kırmızı rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('mor')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Mor rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { morrenk: role.id }, { upsert: true })
            message.lineReply(`Renk menü mor rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('yeşil')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Yeşil rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { yeşilrenk: role.id }, { upsert: true })
            message.lineReply(`Renk menü yeşil rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('turuncu')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Turuncu rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { turuncurenk: role.id }, { upsert: true })
            message.lineReply(`Renk menü turuncu rol ${role} olarak ayarlandı.`)
        }
    }
    if (args[0] && args[0].includes('ilişki')) {
        if (!args[1]) {
            message.lineReply(new MessageEmbed()
           .setDescription(`
           \`\`\` 
           İLİŞKİ SEÇME
           ///////////////////////////////
           .setup ilişki kanal #kanaletiket
           .setup ilişki rolleri @alone @satisfied @lgbt @lovers
           .setup ilişki alone @aloneroletiket
           .setup ilişki satisfied @satisfiedroletiket
           .setup ilişki lgbt @lgbtroletiket
           .setup ilişki lovers @loversroletiket
           \`\`\``)
           )
        }
        if (args[1] && args[1].includes('kanal')) {
            let kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[2])
            if (!args[2] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { ilişkiKanalID: kanal.id }, { upsert: true })
            message.lineReply(`İlişki kanal menüsü başarı ile ${kanal} olarak ayarlandı!`)
        }
        if (args[1] && args[1].includes('rolleri')) {
            let roles = message.mentions.roles.map(c => c.id)
            if (!args[2] || !roles) return message.lineReply('Rollerini belirtmelisin!')
            await data.updateOne({ sunucuID: message.guild.id }, { ilişkiler: roles }, { upsert: true })
            message.lineReply(`İlişki rolleri menüsü başarı ile ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('alone')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Alone rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { alonerol : role.id }, { upsert: true })
            message.lineReply(`İlişki menü alone rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('lgbt')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('LGBT rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { lgbtrol: role.id }, { upsert: true })
            message.lineReply(`İlişki menü lgbt rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('satisfied')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Satisfied rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { satisfiedrol: role.id }, { upsert: true })
            message.lineReply(`İlişki menü satisfied rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('lovers')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Lovers rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { loversrol: role.id }, { upsert: true })
            message.lineReply(`İlişki menü lovers rol ${role} olarak ayarlandı.`)
        }
    }
    if (args[0] && args[0].includes('etkinlik')) {
        if (!args[1]) {
            message.lineReply(new MessageEmbed()
           .setDescription(`
           \`\`\` 
           ETKİNLİK SEÇME
           ///////////////////////////////
           .setup etkinlik kanal #kanaletiket
           .setup etkinlik rolleri @dcrolü @vkrolü @çekilişrolü
           .setup etkinlik dcrol @dcroletiket
           .setup etkinlik vkrol @vkroletiket
           .setup etkinlik çekilişrol @çekilişroletiket
           \`\`\``)
           )
        }
        if (args[1] && args[1].includes('kanal')) {
            let kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[2])
            if (!args[2] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { etkinlikKanalID: kanal.id }, { upsert: true })
            message.lineReply(`Etkinlik kanal menüsü başarı ile ${kanal} olarak ayarlandı!`)
        }
        if (args[1] && args[1].includes('rolleri')) {
            let roles = message.mentions.roles.map(c => c.id)
            if (!args[2] || !roles) return message.lineReply('Rollerini belirtmelisin!')
            await data.updateOne({ sunucuID: message.guild.id }, { etkinlikler: roles }, { upsert: true })
            message.lineReply(`Etkinlik rolleri menüsü başarı ile ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('dcrol')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('DC rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { dcrol : role.id }, { upsert: true })
            message.lineReply(`Etkinlik menü dc rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('vkrol')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('VK rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { vkrol: role.id }, { upsert: true })
            message.lineReply(`Etkinlik menü vk rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('çekilişrol')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Çekiliş rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { çekilişrol: role.id }, { upsert: true })
            message.lineReply(`Etkinlik menü çekiliş rol ${role} olarak ayarlandı.`)
        }
    }
    if (args[0] && args[0].includes('burç')) {
        if (!args[1]) {
            message.lineReply(new MessageEmbed()
           .setDescription(`
           \`\`\` 
           BURÇ SEÇME
           ///////////////////////////////
           .setup burç kanal #kanaletiket
           .setup burç rolleri @başak @akrep @aslan @balık @ikizler @boğa @koç @kova @oğlak @terazi @yay @yengeç
           .setup burç başak @başak
           .setup burç akrep @akrep
           .setup burç aslan @aslan
           .setup burç balık @balık
           .setup burç ikizler @ikizler
           .setup burç boğa @boğa
           .setup burç koç @koç
           .setup burç kova @kova
           .setup burç oğlak @oğlak
           .setup burç terazi @terazi
           .setup burç yay @yay
           .setup burç yengeç @yengeç
           \`\`\``)
           )
        }
        if (args[1] && args[1].includes('kanal')) {
            let kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[2])
            if (!args[2] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { burçKanalID: kanal.id }, { upsert: true })
            message.lineReply(`Burç kanal menüsü başarı ile ${kanal} olarak ayarlandı!`)
        }
        if (args[1] && args[1].includes('rolleri')) {
            let roles = message.mentions.roles.map(c => c.id)
            if (!args[2] || !roles) return message.lineReply('Rollerini belirtmelisin!')
            await data.updateOne({ sunucuID: message.guild.id }, { burçlar: roles }, { upsert: true })
            message.lineReply(`Burç rolleri menüsü başarı ile ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('başak')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Başak rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { başakrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü başak rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('akrep')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Akrep rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { akreprol: role.id }, { upsert: true })
            message.lineReply(`Burç menü akrep rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('aslan')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Aslan rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { aslanrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü aslan rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('balık')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Balık rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { balıkrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü balık rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('ikizler')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('İkizler rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { ikizlerrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü ikizler rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('boğa')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Boğa rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { boğarol: role.id }, { upsert: true })
            message.lineReply(`Burç menü boğa rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('koç')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Koç rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { koçrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü koç rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('kova')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Kova rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { kovarol: role.id }, { upsert: true })
            message.lineReply(`Burç menü kova rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('oğlak')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Oğlak rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { oğlakrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü oğlak rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('terazi')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Terazi rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { terazirol: role.id }, { upsert: true })
            message.lineReply(`Burç menü terazi rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('yay')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Yay rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { yayrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü yay rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('yengeç')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Yengeç rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { yengeçrol: role.id }, { upsert: true })
            message.lineReply(`Burç menü yengeç rol ${role} olarak ayarlandı.`)
        }
        

               }
    if (args[0] && args[0].includes('oyun')) {
        if (!args[1]) {
            message.lineReply(new MessageEmbed()
           .setDescription(`
           \`\`\` 
           OYUN SEÇME
           ///////////////////////////////
           .setup oyun kanal #kanetiket
           .setup oyun rolleri @Gta5 @csgo @pubg @lol @valo @mc @cod @fortnite
           .setup oyun gta5 @gta5
           .setup oyun csgo @csgo
           .setup oyun pubg @pubg
           .setup oyun lol @lol
           .setup oyun valo @valo
           .setup oyun mc @mc
           .setup oyun cod @cod
           .setup oyun fortnite @fortnite
           \`\`\``)
           )
        }
        if (args[1] && args[1].includes('kanal')) {
            let kanal = message.mentions.channels.first() || message.guild.channels.cache.get(args[2])
            if (!args[2] || !kanal) return message.lineReply('Bir kanal belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { oyunKanalID: kanal.id }, { upsert: true })
            message.lineReply(`Oyun kanal menüsü başarı ile ${kanal} olarak ayarlandı!`)
        }
        if (args[1] && args[1].includes('rolleri')) {
            let roles = message.mentions.roles.map(c => c.id)
            if (!args[2] || !roles) return message.lineReply('Rollerini belirtmelisin!')
            await data.updateOne({ sunucuID: message.guild.id }, { oyunlar: roles }, { upsert: true })
            message.lineReply(`Oyun rolleri menüsü başarı ile ${roles.map(c => message.guild.roles.cache.get(c)).join(',')} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('gta5')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Gta5 rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { gtavrol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü gta5 rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('csgo')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Csgo rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { csgorol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü csgo rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('pubg')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Pubg rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { pubgrol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü pubg rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('lol')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Lol rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { lolrol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü lol rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('valo')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Valorant rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { valorol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü valorant rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('mc')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Minecraft rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { mcrol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü minecraft rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('cod')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Cod rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { codrol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü cod rol ${role} olarak ayarlandı.`)
        }
        if (args[1] && args[1].includes('fortnite')) {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
            if (!args[2] || !role) return message.lineReply('Fortnite rolünü belirtmedin!')
            await data.updateOne({ sunucuID: message.guild.id }, { fortniterol: role.id }, { upsert: true })
            message.lineReply(`Oyun menü fortnite rol ${role} olarak ayarlandı.`)
        }
    }
};
module.exports.configuration = {
  name: "setup",
  aliases: ['setup'],
  usage: "setup",
  description: "Setup işte.",
  permLevel: 0
};